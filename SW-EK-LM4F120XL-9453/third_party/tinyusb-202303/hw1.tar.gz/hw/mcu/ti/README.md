# TI MCU Driver

This repository contains a copy of MCU peripheral driver library, original sources are obtained from `https://www.ti.com`

This repository is meant to be included as submodule and conveniently run [Tinyusb](https://github.com/hathach/tinyusb) examples on TI MCUs.
