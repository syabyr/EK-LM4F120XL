/**
  ******************************************************************************
  * @file      startup_gcc_ch32f20x_d8c.s
  * @author    Denis Krasutski
  * @brief     CH32F205 Devices vector table
  *            This module performs:
  *                - Set the initial SP
  *                - Set the initial PC == Reset_Handler,
  *                - Set the vector table entries with the exceptions ISR address
  *                - Branches to main in the C library (which eventually
  *                  calls main()).
  *            After Reset the Cortex-M3 processor is in Thread mode,
  *            priority is Privileged, and the Stack is set to Main.
  ******************************************************************************
  */

.syntax unified
.cpu cortex-m3
.thumb
.global  g_pfnVectors
.global  Default_Handler

/* start address for the initialization values of the .data section. defined in linker script */
.word  _sidata
/* start address for the .data section. defined in linker script */
.word  _sdata
/* end address for the .data section. defined in linker script */
.word  _edata
/* start address for the .bss section. defined in linker script */
.word  _sbss
/* end address for the .bss section. defined in linker script */
.word  _ebss

.section  .text.Reset_Handler
.weak  Reset_Handler
.type  Reset_Handler, %function
Reset_Handler:
  /* set stack pointer */
  ldr   sp, =_estack
  /* Call the clock system initialization function.*/
  bl  SystemInit
  /* Copy the data segment initializers from flash to SRAM */
  ldr r0, =_sdata
  ldr r1, =_edata
  ldr r2, =_sidata
  movs r3, #0
  b LoopCopyDataInit
CopyDataInit:
  ldr r4, [r2, r3]
  str r4, [r0, r3]
  adds r3, r3, #4
LoopCopyDataInit:
  adds r4, r0, r3
  cmp r4, r1
  bcc CopyDataInit

  /* Zero fill the bss segment. */
  ldr r2, =_sbss
  ldr r4, =_ebss
  movs r3, #0
  b LoopFillZerobss
FillZerobss:
  str  r3, [r2]
  adds r2, r2, #4
LoopFillZerobss:
  cmp r2, r4
  bcc FillZerobss
  /* Call static constructors */
  bl __libc_init_array
  /* Call the application's entry point.*/
  bl  main
  bx  lr
  .size  Reset_Handler, .-Reset_Handler

.section  .text.Default_Handler,"ax",%progbits
Default_Handler:
Infinite_Loop:
  b  Infinite_Loop
  .size  Default_Handler, .-Default_Handler

/******************************************************************************
*
* The minimal vector table for a Cortex M3. Note that the proper constructs
* must be placed on this to ensure that it ends up at physical address
* 0x0000.0000.
*
*******************************************************************************/
  .section  .isr_vector,"a",%progbits
  .type  g_pfnVectors, %object
  .size  g_pfnVectors, .-g_pfnVectors

g_pfnVectors:
  .word  _estack
  .word  Reset_Handler
  .word  NMI_Handler
  .word  HardFault_Handler
  .word  MemManage_Handler
  .word  BusFault_Handler
  .word  UsageFault_Handler
  .word  0
  .word  0
  .word  0
  .word  0
  .word  SVC_Handler
  .word  DebugMon_Handler
  .word  0
  .word  PendSV_Handler
  .word  SysTick_Handler

/*******************************************************************************
 External Interrupts
*******************************************************************************/
.word     WWDG_IRQHandler
.word     PVD_IRQHandler
.word     TAMPER_IRQHandler
.word     RTC_IRQHandler
.word     FLASH_IRQHandler
.word     RCC_IRQHandler
.word     EXTI0_IRQHandler
.word     EXTI1_IRQHandler
.word     EXTI2_IRQHandler
.word     EXTI3_IRQHandler
.word     EXTI4_IRQHandler
.word     DMA1_Channel1_IRQHandler
.word     DMA1_Channel2_IRQHandler
.word     DMA1_Channel3_IRQHandler
.word     DMA1_Channel4_IRQHandler
.word     DMA1_Channel5_IRQHandler
.word     DMA1_Channel6_IRQHandler
.word     DMA1_Channel7_IRQHandler
.word     ADC1_2_IRQHandler
.word     USB_HP_CAN1_TX_IRQHandler
.word     USB_LP_CAN1_RX0_IRQHandler
.word     CAN1_RX1_IRQHandler
.word     CAN1_SCE_IRQHandler
.word     EXTI9_5_IRQHandler
.word     TIM1_BRK_IRQHandler
.word     TIM1_UP_IRQHandler
.word     TIM1_TRG_COM_IRQHandler
.word     TIM1_CC_IRQHandler
.word     TIM2_IRQHandler
.word     TIM3_IRQHandler
.word     TIM4_IRQHandler
.word     I2C1_EV_IRQHandler
.word     I2C1_ER_IRQHandler
.word     I2C2_EV_IRQHandler
.word     I2C2_ER_IRQHandler
.word     SPI1_IRQHandler
.word     SPI2_IRQHandler
.word     USART1_IRQHandler
.word     USART2_IRQHandler
.word     USART3_IRQHandler
.word     EXTI15_10_IRQHandler
.word     RTCAlarm_IRQHandler
.word     0
.word     TIM8_BRK_IRQHandler
.word     TIM8_UP_IRQHandler
.word     TIM8_TRG_COM_IRQHandler
.word     TIM8_CC_IRQHandler
.word     RNG_IRQHandler
.word     FSMC_IRQHandler
.word     SDIO_IRQHandler
.word     TIM5_IRQHandler
.word     SPI3_IRQHandler
.word     UART4_IRQHandler
.word     UART5_IRQHandler
.word     TIM6_IRQHandler
.word     TIM7_IRQHandler
.word     DMA2_Channel1_IRQHandler
.word     DMA2_Channel2_IRQHandler
.word     DMA2_Channel3_IRQHandler
.word     DMA2_Channel4_IRQHandler
.word     DMA2_Channel5_IRQHandler
.word     ETH_IRQHandler
.word     ETH_WKUP_IRQHandler
.word     CAN2_TX_IRQHandler
.word     CAN2_RX0_IRQHandler
.word     CAN2_RX1_IRQHandler
.word     CAN2_SCE_IRQHandler
.word     OTG_FS_IRQHandler
.word     USBHSWakeup_IRQHandler
.word     USBHS_IRQHandler
.word     DVP_IRQHandler
.word     UART6_IRQHandler
.word     UART7_IRQHandler
.word     UART8_IRQHandler
.word     TIM9_BRK_IRQHandler
.word     TIM9_UP_IRQHandler
.word     TIM9_TRG_COM_IRQHandler
.word     TIM9_CC_IRQHandler
.word     TIM10_BRK_IRQHandler
.word     TIM10_UP_IRQHandler
.word     TIM10_TRG_COM_IRQHandler
.word     TIM10_CC_IRQHandler
.word     DMA2_Channel6_IRQHandler
.word     DMA2_Channel7_IRQHandler
.word     DMA2_Channel8_IRQHandler
.word     DMA2_Channel9_IRQHandler
.word     DMA2_Channel10_IRQHandler
.word     DMA2_Channel11_IRQHandler

/*******************************************************************************
*
* Provide weak aliases
*
*******************************************************************************/
.weak NMI_Handler
.thumb_set NMI_Handler,Default_Handler

.weak HardFault_Handler
.thumb_set HardFault_Handler,Default_Handler

.weak MemManage_Handler
.thumb_set MemManage_Handler,Default_Handler

.weak BusFault_Handler
.thumb_set BusFault_Handler,Default_Handler

.weak UsageFault_Handler
.thumb_set UsageFault_Handler,Default_Handler

.weak SVC_Handler
.thumb_set SVC_Handler,Default_Handler

.weak DebugMon_Handler
.thumb_set DebugMon_Handler,Default_Handler

.weak PendSV_Handler
.thumb_set PendSV_Handler,Default_Handler

.weak SysTick_Handler
.thumb_set SysTick_Handler,Default_Handler

.weak WWDG_IRQHandler
.thumb_set WWDG_IRQHandler,Default_Handler

.weak PVD_IRQHandler
.thumb_set PVD_IRQHandler,Default_Handler

.weak TAMPER_IRQHandler
.thumb_set TAMPER_IRQHandler,Default_Handler

.weak RTC_IRQHandler
.thumb_set RTC_IRQHandler,Default_Handler

.weak FLASH_IRQHandler
.thumb_set FLASH_IRQHandler,Default_Handler

.weak RCC_IRQHandler
.thumb_set RCC_IRQHandler,Default_Handler

.weak EXTI0_IRQHandler
.thumb_set EXTI0_IRQHandler,Default_Handler

.weak EXTI1_IRQHandler
.thumb_set EXTI1_IRQHandler,Default_Handler

.weak EXTI2_IRQHandler
.thumb_set EXTI2_IRQHandler,Default_Handler

.weak EXTI3_IRQHandler
.thumb_set EXTI3_IRQHandler,Default_Handler

.weak EXTI4_IRQHandler
.thumb_set EXTI4_IRQHandler,Default_Handler

.weak DMA1_Channel1_IRQHandler
.thumb_set DMA1_Channel1_IRQHandler,Default_Handler

.weak DMA1_Channel2_IRQHandler
.thumb_set DMA1_Channel2_IRQHandler,Default_Handler

.weak DMA1_Channel3_IRQHandler
.thumb_set DMA1_Channel3_IRQHandler,Default_Handler

.weak DMA1_Channel4_IRQHandler
.thumb_set DMA1_Channel4_IRQHandler,Default_Handler

.weak DMA1_Channel5_IRQHandler
.thumb_set DMA1_Channel5_IRQHandler,Default_Handler

.weak DMA1_Channel6_IRQHandler
.thumb_set DMA1_Channel6_IRQHandler,Default_Handler

.weak DMA1_Channel7_IRQHandler
.thumb_set DMA1_Channel7_IRQHandler,Default_Handler

.weak ADC1_2_IRQHandler
.thumb_set ADC1_2_IRQHandler,Default_Handler

.weak USB_HP_CAN1_TX_IRQHandler
.thumb_set USB_HP_CAN1_TX_IRQHandler,Default_Handler

.weak USB_LP_CAN1_RX0_IRQHandler
.thumb_set USB_LP_CAN1_RX0_IRQHandler,Default_Handler

.weak CAN1_RX1_IRQHandler
.thumb_set CAN1_RX1_IRQHandler,Default_Handler

.weak CAN1_SCE_IRQHandler
.thumb_set CAN1_SCE_IRQHandler,Default_Handler

.weak EXTI9_5_IRQHandler
.thumb_set EXTI9_5_IRQHandler,Default_Handler

.weak TIM1_BRK_IRQHandler
.thumb_set TIM1_BRK_IRQHandler,Default_Handler

.weak TIM1_UP_IRQHandler
.thumb_set TIM1_UP_IRQHandler,Default_Handler

.weak TIM1_TRG_COM_IRQHandler
.thumb_set TIM1_TRG_COM_IRQHandler,Default_Handler

.weak TIM1_CC_IRQHandler
.thumb_set TIM1_CC_IRQHandler,Default_Handler

.weak TIM2_IRQHandler
.thumb_set TIM2_IRQHandler,Default_Handler

.weak TIM3_IRQHandler
.thumb_set TIM3_IRQHandler,Default_Handler

.weak TIM4_IRQHandler
.thumb_set TIM4_IRQHandler,Default_Handler

.weak I2C1_EV_IRQHandler
.thumb_set I2C1_EV_IRQHandler,Default_Handler

.weak I2C1_ER_IRQHandler
.thumb_set I2C1_ER_IRQHandler,Default_Handler

.weak I2C2_EV_IRQHandler
.thumb_set I2C2_EV_IRQHandler,Default_Handler

.weak I2C2_ER_IRQHandler
.thumb_set I2C2_ER_IRQHandler,Default_Handler

.weak SPI1_IRQHandler
.thumb_set SPI1_IRQHandler,Default_Handler

.weak SPI2_IRQHandler
.thumb_set SPI2_IRQHandler,Default_Handler

.weak USART1_IRQHandler
.thumb_set USART1_IRQHandler,Default_Handler

.weak USART2_IRQHandler
.thumb_set USART2_IRQHandler,Default_Handler

.weak USART3_IRQHandler
.thumb_set USART3_IRQHandler,Default_Handler

.weak EXTI15_10_IRQHandler
.thumb_set EXTI15_10_IRQHandler,Default_Handler

.weak RTCAlarm_IRQHandler
.thumb_set RTCAlarm_IRQHandler,Default_Handler

.weak TIM8_BRK_IRQHandler
.thumb_set TIM8_BRK_IRQHandler,Default_Handler

.weak TIM8_UP_IRQHandler
.thumb_set TIM8_UP_IRQHandler,Default_Handler

.weak TIM8_TRG_COM_IRQHandler
.thumb_set TIM8_TRG_COM_IRQHandler,Default_Handler

.weak TIM8_CC_IRQHandler
.thumb_set TIM8_CC_IRQHandler,Default_Handler

.weak RNG_IRQHandler
.thumb_set RNG_IRQHandler,Default_Handler

.weak FSMC_IRQHandler
.thumb_set FSMC_IRQHandler,Default_Handler

.weak SDIO_IRQHandler
.thumb_set SDIO_IRQHandler,Default_Handler

.weak TIM5_IRQHandler
.thumb_set TIM5_IRQHandler,Default_Handler

.weak SPI3_IRQHandler
.thumb_set SPI3_IRQHandler,Default_Handler

.weak UART4_IRQHandler
.thumb_set UART4_IRQHandler,Default_Handler

.weak UART5_IRQHandler
.thumb_set UART5_IRQHandler,Default_Handler

.weak TIM6_IRQHandler
.thumb_set TIM6_IRQHandler,Default_Handler

.weak TIM7_IRQHandler
.thumb_set TIM7_IRQHandler,Default_Handler

.weak DMA2_Channel1_IRQHandler
.thumb_set DMA2_Channel1_IRQHandler,Default_Handler

.weak DMA2_Channel2_IRQHandler
.thumb_set DMA2_Channel2_IRQHandler,Default_Handler

.weak DMA2_Channel3_IRQHandler
.thumb_set DMA2_Channel3_IRQHandler,Default_Handler

.weak DMA2_Channel4_IRQHandler
.thumb_set DMA2_Channel4_IRQHandler,Default_Handler

.weak DMA2_Channel5_IRQHandler
.thumb_set DMA2_Channel5_IRQHandler,Default_Handler

.weak ETH_IRQHandler
.thumb_set ETH_IRQHandler,Default_Handler

.weak ETH_WKUP_IRQHandler
.thumb_set ETH_WKUP_IRQHandler,Default_Handler

.weak CAN2_TX_IRQHandler
.thumb_set CAN2_TX_IRQHandler,Default_Handler

.weak CAN2_RX0_IRQHandler
.thumb_set CAN2_RX0_IRQHandler,Default_Handler

.weak CAN2_RX1_IRQHandler
.thumb_set CAN2_RX1_IRQHandler,Default_Handler

.weak CAN2_SCE_IRQHandler
.thumb_set CAN2_SCE_IRQHandler,Default_Handler

.weak OTG_FS_IRQHandler
.thumb_set OTG_FS_IRQHandler,Default_Handler

.weak USBHSWakeup_IRQHandler
.thumb_set USBHSWakeup_IRQHandler,Default_Handler

.weak USBHS_IRQHandler
.thumb_set USBHS_IRQHandler,Default_Handler

.weak DVP_IRQHandler
.thumb_set DVP_IRQHandler,Default_Handler

.weak UART6_IRQHandler
.thumb_set UART6_IRQHandler,Default_Handler

.weak UART7_IRQHandler
.thumb_set UART7_IRQHandler,Default_Handler

.weak UART8_IRQHandler
.thumb_set UART8_IRQHandler,Default_Handler

.weak TIM9_BRK_IRQHandler
.thumb_set TIM9_BRK_IRQHandler,Default_Handler

.weak TIM9_UP_IRQHandler
.thumb_set TIM9_UP_IRQHandler,Default_Handler

.weak TIM9_TRG_COM_IRQHandler
.thumb_set TIM9_TRG_COM_IRQHandler,Default_Handler

.weak TIM9_CC_IRQHandler
.thumb_set TIM9_CC_IRQHandler,Default_Handler

.weak TIM10_BRK_IRQHandler
.thumb_set TIM10_BRK_IRQHandler,Default_Handler

.weak TIM10_UP_IRQHandler
.thumb_set TIM10_UP_IRQHandler,Default_Handler

.weak TIM10_TRG_COM_IRQHandler
.thumb_set TIM10_TRG_COM_IRQHandler,Default_Handler

.weak TIM10_CC_IRQHandler
.thumb_set TIM10_CC_IRQHandler,Default_Handler

.weak DMA2_Channel6_IRQHandler
.thumb_set DMA2_Channel6_IRQHandler,Default_Handler

.weak DMA2_Channel7_IRQHandler
.thumb_set DMA2_Channel7_IRQHandler,Default_Handler

.weak DMA2_Channel8_IRQHandler
.thumb_set DMA2_Channel8_IRQHandler,Default_Handler

.weak DMA2_Channel9_IRQHandler
.thumb_set DMA2_Channel9_IRQHandler,Default_Handler

.weak DMA2_Channel10_IRQHandler
.thumb_set DMA2_Channel10_IRQHandler,Default_Handler

.weak DMA2_Channel11_IRQHandler
.thumb_set DMA2_Channel11_IRQHandler,Default_Handler
